pref("extensions.shortly.clipboard.enable", true);
pref("extensions.shortly.accesskey.enable", true);
pref("extensions.shortly.accesskey.combination", "CTRL-ALT-S");
